package user;

public class User {
    public String phone;
    public String name;
    public String email;
    public String address;
    public String password;
}
